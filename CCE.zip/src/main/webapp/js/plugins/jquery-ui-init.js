(function ($) {
    'use strict'
    $("#datepicker").datepicker({
        dateFormat: "dd-mm-yy",
        duration: "fast"
    });
})(jQuery);