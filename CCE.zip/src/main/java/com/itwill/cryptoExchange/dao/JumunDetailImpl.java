package com.itwill.cryptoExchange.dao;

import java.util.List;

import com.itwill.cryptoExchange.dto.JumunDetail;

public class JumunDetailImpl implements JumunDetailDao{

	@Override
	public List<JumunDetail> selectAllByAccountNo(int accountNo) throws Exception {
		
		return null;
	}

	@Override
	public List<JumunDetail> selectAllByProductNo(int productNo) throws Exception {
		
		return null;
	}

	@Override
	public List<JumunDetail> selectAll(int accountNo, int productNo) throws Exception {
		
		return null;
	}

	@Override
	public boolean insertJumunDetail(JumunDetail jumunDetail) throws Exception {
		
		return false;
	}

	@Override
	public JumunDetail selectJumunDetail(int jumunNo) throws Exception {
		
		return null;
	}

	@Override
	public boolean deleteJumunDetail(int jumunNo) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateJumunDetail(JumunDetail jumunDetail) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

}
